/*
class Animal{
    public string? Nome {get; set;}
    public int Idade {get; set;}

    public virtual string emitirSom(){
        return "som de um animal";
    }
}

class Cachorro : Animal{
    public override string emitirSom(){
        return $"o {Nome} esta latindo!!";
    }
}

class Gato : Animal{
    public override string emitirSom(){
        return $"o {Nome} esta miando";
    }
}
*/