﻿do{ //SISTEMA DE REPETIÇÃO

    //PEDE O NOME DO ALUNO
    Console.WriteLine("Digite o nome do aluno:");
    string nome_aluno = Console.ReadLine();

    //PEDE A NOTA 1 NO ALUNO
    Console.WriteLine("Digite a primeira nota: ");
    double nota1 = Convert.ToDouble(Console.ReadLine());

    //PEDE A NOTA 2 NO ALUNO
    Console.WriteLine("Digite a segunda nota: ");
    double nota2 = Convert.ToDouble(Console.ReadLine());

    //PEDE A NOTA 3 NO ALUNO
    Console.WriteLine("Digite a terceira nota: ");
    double nota3 = Convert.ToDouble(Console.ReadLine());

    //MEDIA
    double media = (nota1+nota2+nota3)/3;

    //VE SE A NOTA ESTA ASSIM OU ABAIXO DA MEDIA E RETORNA SE ESTA APROVADO OU REPROVADO
    if (media >=7){
        Console.WriteLine($"O aluno {nome_aluno}\n Nota1: {nota1}\n Nota2: {nota2}\n Nota3: {nota3}\n com media {media} esta APROVADO!");
    }else{
        Console.WriteLine($"O aluno {nome_aluno}\n Nota1: {nota1}\n Nota2: {nota2}\n Nota3: {nota3}\n com media {media} esta REPROVADO!");
    }

    //PERGUNTA AO USUARIO SE QUER REPETIR O CODIGO OU CONTINUAR
    Console.WriteLine("Quer calcular a media de outro aluno? (s/n)");
    string opcao = Console.ReadLine();
    if (opcao != "s"){
        break;
    }

}while(true); //SISTEMA DE REPETIÇÃO
